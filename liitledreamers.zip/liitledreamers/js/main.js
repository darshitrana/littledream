$('.dream_right_slider').slick({

    slidesToShow: 1,
    responsive: [{
            breakpoint: 768,
            settings: {
                arrows: false,

                slidesToShow: 1
            }
        },
        {
            breakpoint: 480,
            settings: {
                arrows: false,
                slidesToShow: 1
            }
        }
    ]
});

$('.response_slider').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    prevArrow: "<button type='button' class='slick-prev pull-left arrows'><img src='image/left-chevron1.png'></button>",
    nextArrow: "<button type='button' class='slick-next pull-right arrows'><img src='image/right-chevron1.png'></button>",
    responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: true,
                dots: true
            }
        },
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                arrows: false,
                autoplay: true,
                autoplaySpeed: 1000,
                dots: true
            }
        },
        {
            breakpoint: 575,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,
                autoplay: true,
                autoplaySpeed: 2000,
                dots: true
            }
        }

    ]
});

$('.slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    fade: true,
    dots: true,
    autoplay: true,
    asNavFor: '.slider-nav',
    prevArrow: "<button type='button' class='slick-prev pull-left arrows'><img src='image/left-chevron.png'></button>",
    nextArrow: "<button type='button' class='slick-next pull-right arrows'><img src='image/right-chevron.png'></button>"
});
$('.slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.slider-for',
    dots: false,
    arrows: false,
    focusOnSelect: true
});


$(document).ready(function () {

    $('.toggle').click(function () {
        $('.menu').slideToggle('show');
        $('body').toggleClass('active');
    });
});

// var $animation_elements = $('.animation-element');
// var $window = $(window);

// function check_if_in_view() {
//     var window_height = $window.height();
//     var window_top_position = $window.scrollTop();
//     var window_bottom_position = (window_top_position + window_height);

//     $.each($animation_elements, function () {
//         var $element = $(this);
//         var element_height = $element.outerHeight();
//         var element_top_position = $element.offset().top;
//         var element_bottom_position = (element_top_position + element_height);

//         //check to see if this current container is within viewport
//         if ((element_bottom_position >= window_top_position) &&
//             (element_top_position <= window_bottom_position)) {
//             $element.addClass('in-view');
//         } else {
//             $element.removeClass('in-view');
//         }
//     });
// }

// $window.on('scroll resize', check_if_in_view);
// $window.trigger('scroll');




$(window).on('scroll', function () {
    if ($(this).scrollTop() > 50) {
        $('.header_menu').addClass("sticky");
    } else {
        $('.header_menu').removeClass("sticky");
    }
});



AOS.init();